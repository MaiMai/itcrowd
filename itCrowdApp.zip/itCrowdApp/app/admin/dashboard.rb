ActiveAdmin.register_page "Dashboard" do

  menu :priority => 1, :label => proc{ I18n.t("active_admin.dashboard") }

  content :title => proc{ I18n.t("active_admin.dashboard") } do
    # div :class => "blank_slate_container", :id => "dashboard_default_message" do
    #   span :class => "blank_slate" do
    #     span I18n.t("active_admin.dashboard_welcome.welcome")
    #     small I18n.t("active_admin.dashboard_welcome.call_to_action")
    #   end
    # end

    # Here is an example of a simple dashboard with columns and panels.
    # number_to_currency
    columns do
      column do
        panel "Recent Users" do
          table_for User.order('last_sign_in_at DESC').limit(10).each do |user|
            column("Name")     {|user| user.name } 
            column("Email")    {|user| link_to(user.email, admin_user_path(user)) }
          end
          # table_for User.order('last_sign_in_at').limit(10) do
          #   column("Vendor")   {|user| user.vendor } 
          #   column("Name"){|user| user.name } 
          #   column("Email")   {|user| link_to(user.user.email, admin_customer_path(user.user)) } 
          # end
          #Facturasfake.order("dateat DESC").limit(1000)
        end
      end

      column do
        panel "Info" do
          h4 "Bienvenido al Dashboard de Blue Ride"
          para "Aqui podremos agregar informacion util en un futuro"

        end
      end
    end
  end # content
end
