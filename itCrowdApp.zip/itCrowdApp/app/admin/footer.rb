class Footer < ActiveAdmin::Component
 
  def build
    super :id => "footer"
 
    span "Powered by BestBuy Business Innovation #{Date.today.year}"
  end
 
end