class ArticlesController < InheritedResources::Base

  def index
  	filtro = []
  	filtro.push("type_ident = #{params[:type_ident].to_i}") if params.has_key?(:type_ident) && is_numeric?(params[:type_ident])
  	filtro.push("model_ident = #{params[:model_ident].to_i}") if params.has_key?(:model_ident) && is_numeric?(params[:model_ident])
  	filtro.push("current_owner = #{params[:current_owner].to_i}") if params.has_key?(:current_owner) && is_numeric?(params[:current_owner])
  	filtro.push("location_id = #{params[:location].to_i}") if params.has_key?(:location) && is_numeric?(params[:location])
  	filtro.push("status = '#{params[:status].gsub("%20"," ")}'") if params.has_key?(:status) && params[:status].gsub("%20"," ").length < 15
  	filtro = filtro.join(" AND ")

    @articles = Article
    	.joins("LEFT JOIN `machines` ON articles.model_ident = machines.id LEFT JOIN `phones` ON articles.model_ident = phones.id LEFT JOIN `lines` ON articles.model_ident = lines.id LEFT JOIN `locations` ON articles.location_id = locations.id LEFT JOIN `employees` ON articles.current_owner = employees.id")
    	.select("articles.*, machines.model as mmodel, machines.brand as mbrand, phones.model as pmodel, phones.brand as pbrand, lines.model as lmodel, lines.brand as lbrand, locations.location, employees.name, employees.netNumber, employees.position, employees.area")
    	.where(filtro)
    	.order("updated_at")

    respond_to do |format|
      format.html { @articles = @articles.page(params[:page]) }
      format.xls 
      format.json { render json: @articles }
    end
  end

  def show
    @article = Article.find(params[:id], 
            :select => "articles.*, machines.model as mmodel, machines.brand as mbrand, phones.model as pmodel, phones.brand as pbrand, lines.model as lmodel, lines.brand as lbrand, locations.location, employees.name",
            :joins  => "LEFT JOIN `machines` ON articles.model_ident = machines.id LEFT JOIN `phones` ON articles.model_ident = phones.id LEFT JOIN `lines` ON articles.model_ident = lines.id LEFT JOIN `locations` ON articles.location_id = locations.id LEFT JOIN `employees` ON articles.current_owner = employees.id" )  	
    @current_owner = Employee.where("id = ?", @article.current_owner).first
    @last_owner    = Employee.where("id = ?", @article.last_owner).first

    @comments = @article.comments

    #redirect_to articles_url
  end

  def add_new_comment
    @post = Article.find params[:id]
    @comment = @post.comments.new params[:comment]
    if @comment.save
      redirect_to @post, notice: "Comentario agregado exitosamente"
    else
      redirect_to @post, alert: "Error al agregar comentario"
    end
  end
  
  private
    def is_numeric?(s)
      !!Float(s) rescue false
    end


end
