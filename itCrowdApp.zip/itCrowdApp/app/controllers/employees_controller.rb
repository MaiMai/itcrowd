class EmployeesController < InheritedResources::Base

  def index
    @employees = Employee.order(:netNumber).page(params[:page])

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @employees }
    end
  end

  def show
    redirect_to employees_url
  end

end
