class LinesController < InheritedResources::Base

  def index
    @lines = Line.order(:brand).page(params[:page])

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @lines }
    end
  end

  def show
    redirect_to lines_url
  end

end
