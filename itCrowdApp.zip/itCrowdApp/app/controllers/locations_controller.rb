class LocationsController < InheritedResources::Base

  def index
    @locations = Location.order(:location).page(params[:page])

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @locations }
    end
  end

  def show
    redirect_to locations_url
  end
  
end
