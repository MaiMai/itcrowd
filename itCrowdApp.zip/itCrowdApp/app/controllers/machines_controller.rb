class MachinesController < InheritedResources::Base

  def index
    @machines = Machine.order(:brand, :model).page(params[:page])

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @machines }
    end
  end

  def show
    redirect_to machines_url
  end

end
