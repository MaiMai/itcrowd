class PhonesController < InheritedResources::Base

  def index
    @phones = Phone.order(:brand,:model).page(params[:page])

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @phones }
    end
  end

  def show
    redirect_to phones_url
  end

end
