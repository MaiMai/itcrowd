#!/bin/env ruby
# encoding: utf-8
class StaticPagesController < ApplicationController
  before_filter :authenticate_user!, :except => [:tos, :privacy]
  rescue_from ActiveRecord::RecordNotFound, :with => :not_found

  def index
  end

  def tos
  end

  def privacy
  end

  def password_reset
    sign_out
    redirect_to "/users/password/new"
  end

  protected
    def not_found
      flash[:error] = "Tal vez allí estaba Wally, pero ya no está."
      redirect_to root_path
    end

end
