module MachinesHelper
end
