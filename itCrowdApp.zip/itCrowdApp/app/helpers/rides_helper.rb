module RidesHelper
end
