module StaticPagesHelper


end
