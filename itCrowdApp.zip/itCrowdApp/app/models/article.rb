class Article < ActiveRecord::Base
  attr_accessible :account_num, :contract_end, :contract_start, :current_owner, :last_owner, :location_id, :model_ident, :notes, :status, :status_date, :type_ident, :unique_num


  validates :type_ident,  presence: true
  validates :model_ident,  presence: true
  validates :unique_num,  presence: true
  validates :location_id,  presence: true
  validates :status,  presence: true
  validates :status_date,  presence: true

  acts_as_commentable


end
