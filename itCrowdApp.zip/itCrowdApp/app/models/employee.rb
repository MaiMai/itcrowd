class Employee < ActiveRecord::Base
  attr_accessible :area, :name, :netNumber, :position

  before_save do |employee| 
  	employee.netNumber = employee.netNumber.downcase
  end

  validates :name, presence: true, length: { maximum: 100 }
  validates :netNumber, presence: true, length: { maximum: 8 }, uniqueness: { case_sensitive: false }
  validates :position, presence: true, length: { maximum: 100 }
  validates :area, presence: true, length: { maximum: 15 }

end
