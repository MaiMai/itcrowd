class Line < ActiveRecord::Base
  attr_accessible :brand, :model

  validates :brand,  presence: true, length: { maximum: 15 }
  validates :model,  presence: true, length: { maximum: 100 }, uniqueness: { case_sensitive: false }

end
