class Location < ActiveRecord::Base
  attr_accessible :location

  validates :location,  presence: true, length: { maximum: 3 }, uniqueness: { case_sensitive: false }

end
