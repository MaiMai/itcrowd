class Machine < ActiveRecord::Base
  attr_accessible :brand, :model

  validates :brand,  presence: true, length: { maximum: 15 }
  validates :model,  presence: true, length: { maximum: 50 }, uniqueness: { case_sensitive: false }

end
