class User < ActiveRecord::Base
  devise :database_authenticatable, :recoverable, 
         :rememberable, :trackable, :validatable, :confirmable
  attr_accessible :name, :email, :password, :password_confirmation, 
                  :remember_me, :comments, :bio, :avatar

  has_many :comments

  has_attached_file :avatar, :styles => { :medium => "300x300>", :thumb => "100x100>" }, :default_url => "/images/:style/missing.png"

  def only_if_unconfirmed
    pending_any_confirmation {yield}
  end
end