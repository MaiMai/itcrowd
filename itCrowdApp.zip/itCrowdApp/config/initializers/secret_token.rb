# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BlogOTRO::Application.config.secret_token = 'c8762f3565cb67db9860c03d9145f2e131f648137d8d9927ac08e0d1cc4b657161d14157a978cf758684dd5dd040e02164f4d98a7cca4da1a5e442f8b286e5d6'
