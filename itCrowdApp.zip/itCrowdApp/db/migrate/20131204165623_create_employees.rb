class CreateEmployees < ActiveRecord::Migration
  def change
    create_table :employees do |t|
      t.string :netNumber
      t.string :name
      t.string :position
      t.string :area

      t.timestamps
    end
  end
end
