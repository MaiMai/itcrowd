class CreateLines < ActiveRecord::Migration
  def change
    create_table :lines do |t|
      t.string :brand
      t.string :model

      t.timestamps
    end
  end
end
