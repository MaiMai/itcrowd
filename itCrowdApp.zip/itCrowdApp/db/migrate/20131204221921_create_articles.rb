class CreateArticles < ActiveRecord::Migration
  def change
    create_table :articles do |t|
      t.integer :type_ident
      t.integer :model_ident
      t.string :unique_num
      t.string :account_num
      t.integer :location_id
      t.integer :current_owner
      t.integer :last_owner
      t.string :status
      t.date :status_date
      t.date :contract_start
      t.date :contract_end
      t.text :notes

      t.timestamps
    end
  end
end
