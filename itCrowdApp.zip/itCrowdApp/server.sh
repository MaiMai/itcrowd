ssh -i ../../ACCESOS/server_r3/dedicado.pem ubuntu@50.17.225.140
