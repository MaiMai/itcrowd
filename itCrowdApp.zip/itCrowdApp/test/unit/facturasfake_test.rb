require 'test_helper'

class FacturasfakeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
