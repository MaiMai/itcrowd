require 'test_helper'

class MachinesHelperTest < ActionView::TestCase
end
