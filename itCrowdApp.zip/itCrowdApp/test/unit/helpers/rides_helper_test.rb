require 'test_helper'

class RidesHelperTest < ActionView::TestCase
end
